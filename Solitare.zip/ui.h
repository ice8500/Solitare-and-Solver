#ifndef UI_H
#define UI_H

#include "card.h"

const char* getRankStr(int rank);
void printGame(DeckStack tableau[7], DeckStack foundation[4], DeckStack *stock, DeckStack *waste);

#endif